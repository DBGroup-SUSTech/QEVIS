with ss as (
 select ss_item_sk, ss_ext_sales_price,
  case when ss_sold_date_sk < 2451729 then 2451729
  else ss_sold_date_sk end
  as ss_sold_date_sk
 from store_sales
)
select  i_brand_id brand_id,
  sum(ss_ext_sales_price) as ext_price
 from date_dim cross join ss cross join item
 where d_date_sk = ss_sold_date_sk
  and ss_item_sk = i_item_sk
  and i_manager_id=13
  and d_moy=11
  and d_year=1999
 group by ss_sold_date_sk, i_brand_id
 order by ext_price desc, i_brand_id
limit 100;
-- mid value
-- tpcds_text_20
